import { Command } from "ckeditor5/src/core";
import {
  getClosestSelectedBootstrapParallaxElement,
  isBootstrapParallaxContainer,
} from "./utils";

/**
 * Creates a new BS Parallax
 *
 * @param {module:engine/model/writer~Writer} writer
 *   The model writer.
 * @param {{}} settings
 *   The settings
 * @return {*}
 *   The parallax.
 */
function createBsParallax(writer, settings) {

  const parallaxAttributes = { class: "bs_parallax" };
  const bsParallax = writer.createElement("bsParallax", parallaxAttributes);

  const containerAttributes = { class: 'parallax-section' };
  const bsParallaxContainer = writer.createElement("bsParallaxContainer", containerAttributes);

  const colAttributes = { class: "parallax-element", data: settings.image };
  const bsParallaxCol = writer.createElement("bsParallaxCol", colAttributes);

  const titleAttributes = { class: "parallax-title " + settings.title_style };
  const colcontent = writer.createElement(settings.title_element, titleAttributes );
  
  console.log(settings.title_style);
  console.log(titleAttributes);
  
  writer.insertText(settings.title, colcontent);

  writer.append(colcontent, bsParallaxCol);
  writer.append(bsParallaxCol, bsParallaxContainer);
  writer.append(bsParallaxContainer, bsParallax);
  return bsParallax;

}

/**
 * Updates an existing BS Parallax
 *
 * @param {module:engine/model/writer~Writer} writer
 *   The model writer.
 * @param {module:engine/view/element~Element|null} existingParallax
 * @param {{}} settings
 *   The settings
 */
function updateExisting(writer, existingParallax, settings) {
  // Parallax.
  //~ const parallaxAttributes = { class: "bs_parallax" };
  //~ writer.setAttributes(parallaxAttributes, existingParallax);

  //~ let container = existingParallax.getChild(0);
  
  //~ const containerAttributes = { class: settings.container_style };
  //~ writer.setAttributes(containerAttributes, container);

  //~ writer.setAttributes({ class: settings.inner_container_class + ' ' + settings.inner_container_style }, container.getChild(0));

}

/**
 * Inserts a parallax or updates a new one.
 */
export default class InsertBootstrapParallaxCommand extends Command {
  execute(settings) {
    const { model } = this.editor;
    const existingParallax = getClosestSelectedBootstrapParallaxElement(
      model.document.selection
    );

    model.change((writer) => {
      if (existingParallax) {
        updateExisting(writer, existingParallax, settings);
      } else {
        model.insertContent(createBsParallax(writer, settings));
      }
    });
  }

  refresh() {
    const { model } = this.editor;
    const { selection } = model.document;
    const allowedIn = model.schema.findAllowedParent(
      selection.getFirstPosition(),
      "bsParallax"
    );
    this.isEnabled = allowedIn !== null;
  }
}
