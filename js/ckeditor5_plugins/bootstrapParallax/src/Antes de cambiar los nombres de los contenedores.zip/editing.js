import { Plugin } from "ckeditor5/src/core";
import { Widget, toWidget, toWidgetEditable } from "ckeditor5/src/widget";
import InsertBootstrapParallaxCommand from "./command";

/**
 * Defines the editing commands for BS Parallax.
 */
export default class BootstrapParallaxEditing extends Plugin {
  /**
   * @inheritdoc
   */
  static get requires() {
    return [Widget];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return "BootstrapParallaxEditing";
  }

  constructor(editor) {
    super(editor);
    this.attrs = {
      class: "class",
      "data": "data",
    };
  }

  init() {
    const options = this.editor.config.get("bootstrapParallax");
    if (!options) {
      return;
    }

    this._defineSchema();
    this._defineConverters();
    this._defineCommands();
  }

  /*
   * This registers the structure that will be seen by CKEditor 5 as
   * <bsParallax>
   *    <bsParallaxContainer>
   *        <bsParallaxCol .. />
   *    </parallaxContainer>
   * </bsParallax>
   *
   * The logic in _defineConverters() will determine how this is converted to
   * markup.
   */
  _defineSchema() {
    const { schema } = this.editor.model;
    schema.register("bsParallax", {
      allowWhere: "$block",
      isLimit: true,
      isObject: true,
      allowAttributes: ["class"],
    });
    schema.register("bsParallaxContainer", {
      isLimit: true,
      allowIn: "bsParallax",
      isInline: true,
      allowAttributes: ["class"],
    });
    schema.register("bsParallaxCol", {
      allowIn: "bsParallaxContainer",
      isInline: true,
      allowContentOf: "$root",
      allowAttributes: Object.keys(this.attrs),
    });
  }

  /**
   * Converters determine how CKEditor 5 models are converted into markup and
   * vice-versa.
   */
  _defineConverters() {
    const { conversion } = this.editor;

    // <bsParallax>
    conversion.for("upcast").elementToElement({
      model: "bsParallax",
      view: {
        name: "div",
        classes: "bs_parallax",
      },
    });

    conversion.for("downcast").elementToElement({
      model: "bsParallax",
      view: (modelElement, { writer }) => {
        const container = writer.createContainerElement("div", {
          class: "bs_parallax",
        });
        writer.setCustomProperty("bsParallax", true, container);
        return toWidget(container, writer, { label: "BS Parallax" });
      },
    });

    // <bsParallaxContainer>
    conversion.for("upcast").elementToElement({
      model: "bsParallaxContainer",
      view: {
        name: "section",
      },
    });

    conversion.for("downcast").elementToElement({
      model: "bsParallaxContainer",
      view: (modelElement, { writer }) => {
        const container = writer.createContainerElement("section");
        writer.setCustomProperty("bsParallaxContainer", true, container);
        return toWidget(container, writer, { label: "BS Parallax Container" });
      },
    });

    // <bsParallaxCol>
    conversion.for("upcast").elementToElement({
      view: {
        name: "div",
        classes: ["parallax-element"],
      },
      converterPriority: "high",
      model: (viewElement, {writer}) => {
        return writer.createElement("bsParallaxCol", {
          class: viewElement.getAttribute('class') || "parallax-element",
        });
      },
    });

    conversion.for("downcast").elementToElement({
      model: "bsParallaxCol",
      view: (modelElement, { writer }) => {
        const rowAttributes = {
          "class": modelElement.getAttribute('class') || "parallax-element",
          "data": modelElement.getAttribute("data"),
        };
        const container = writer.createContainerElement("div", rowAttributes);
        writer.setCustomProperty("bsParallaxCol", true, container);
        return toWidget(container, writer, { label: "BS Parallax Col" });
      },
    });

    

    // Set attributeToAttribute conversion for all supported attributes.
    Object.keys(this.attrs).forEach((modelKey) => {
      const attributeMapping = {
        model: {
          key: modelKey,
          name: "bsParallaxCol",
        },
        view: {
          name: "div",
          key: this.attrs[modelKey],
        },
      };
      conversion.for("downcast").attributeToAttribute(attributeMapping);
      conversion.for("upcast").attributeToAttribute(attributeMapping);
    });

    conversion.attributeToAttribute({ model: "class", view: "class" });

  }

  /**
   * Defines the BS Parallax commands.
   *
   * @private
   */
  _defineCommands() {
    this.editor.commands.add(
      "insertBootstrapParallax",
      new InsertBootstrapParallaxCommand(this.editor)
    );
  }
}
