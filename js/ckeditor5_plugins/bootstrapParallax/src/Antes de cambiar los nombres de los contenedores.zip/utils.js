import { isWidget } from "ckeditor5/src/widget";

/**
 * Checks if the provided model element is `bsParallax`.
 *
 * @param {module:engine/model/element~Element} modelElement
 *   The model element to be checked.
 * @return {boolean}
 *   A boolean indicating if the element is a bsParallax element.
 *
 * @private
 */
export function isBootstrapParallax(modelElement) {
  return !!modelElement && modelElement.is("element", "bsParallax");
}

/**
 * Checks if the provided model element is `bsParallaxContainer`.
 *
 * @param {module:engine/model/element~Element} modelElement
 *   The model element to be checked.
 * @return {boolean}
 *   A boolean indicating if the element is a bsParallaxContainer element.
 *
 * @private
 */
export function isBootstrapParallaxContainer(modelElement) {
  return !!modelElement && modelElement.is("element", "bsParallaxContainer");
}

/**
 * Checks if view element is <bsParallax> element.
 *
 * @param {module:engine/view/element~Element} viewElement
 *   The view element.
 * @return {boolean}
 *   A boolean indicating if the element is a <bsParallax> element.
 *
 * @private
 */
export function isBootstrapParallaxWidget(viewElement) {
  return isWidget(viewElement) && !!viewElement.getCustomProperty("bsParallax");
}

/**
 * Checks if view element is <bsParallaxContainer> element.
 *
 * @param {module:engine/view/element~Element} viewElement
 *   The view element.
 * @return {boolean}
 *   A boolean indicating if the element is a <bsParallaxContainer> element.
 *
 * @private
 */
export function isBootstrapParallaxContainerWidget(viewElement) {
  return (
    isWidget(viewElement) && !!viewElement.getCustomProperty("bsParallaxContainer")
  );
}

/**
 * Checks if view element is <bsParallaxRow> element.
 *
 * @param {module:engine/view/element~Element} viewElement
 *   The view element.
 * @return {boolean}
 *   A boolean indicating if the element is a <bsParallaxRow> element.
 *
 * @private
 */
export function isBootstrapParallaxRowWidget(viewElement) {
  return isWidget(viewElement) && !!viewElement.getCustomProperty("bsParallaxRow");
}

/**
 * Checks if view element is <bsParallaxCol> element.
 *
 * @param {module:engine/view/element~Element} viewElement
 *   The view element.
 * @return {boolean}
 *   A boolean indicating if the element is a <bsParallaxCol> element.
 *
 * @private
 */
export function isBootstrapParallaxColWidget(viewElement) {
  return !!viewElement.getCustomProperty("bsParallaxCol");
}

/**
 * Gets `bsParallax` element from selection.
 *
 * @param {module:engine/model/selection~Selection|module:engine/model/documentselection~DocumentSelection} selection
 *   The current selection.
 * @return {module:engine/model/element~Element|null}
 *   The `bsParallax` element which could be either the current selected an
 *   ancestor of the selection. Returns null if the selection has no Parallax
 *   element.
 *
 * @private
 */
export function getClosestSelectedBootstrapParallaxElement(selection) {
  const selectedElement = selection.getSelectedElement();

  return isBootstrapParallax(selectedElement)
    ? selectedElement
    : selection.getFirstPosition().findAncestor("bsParallax");
}

/**
 * Gets selected BsParallax widget if only BsParallax is currently selected.
 *
 * @param {module:engine/model/selection~Selection} selection
 *   The current selection.
 * @return {module:engine/view/element~Element|null}
 *   The currently selected Parallax widget or null.
 *
 * @private
 */
export function getClosestSelectedBootstrapParallaxWidget(selection) {
  const viewElement = selection.getSelectedElement();
  if (viewElement && isBootstrapParallaxWidget(viewElement)) {
    return viewElement;
  }

  // Perhaps nothing is selected.
  if (selection.getFirstPosition() === null) {
    return null;
  }

  let { parent } = selection.getFirstPosition();
  while (parent) {
    if (parent.is("element") && isBootstrapParallaxWidget(parent)) {
      return parent;
    }
    parent = parent.parent;
  }
  return null;
}

/**
 * Extracts classes for settings.
 *
 * @param {*} element
 *   The element being passed.
 * @param {string} base
 *   The base class to exclude.
 * @param {boolean} reverse
 *   Whether to reverse the affect.
 * @return {string|string|string}
 *   The class list.
 */
export function extractParallaxClasses(element, base, reverse) {
  reverse = reverse || false;
  let classes = "";

  if (typeof element.getAttribute === "function") {
    classes = element.getAttribute("class");
  } else if (typeof element.className === "string") {
    classes = element.className;
  }

  // Failsafe.
  if (!classes) {
    return "";
  }

  const classlist = classes.split(" ").filter((c) => {
    if (
      c.lastIndexOf("ck-widget", 0) === 0 ||
      c.lastIndexOf("ck-edit", 0) === 0 ||
      c.lastIndexOf("bsg-", 0) === 0
    ) {
      return false;
    }
    return reverse
      ? c.lastIndexOf(base, 0) === 0
      : c.lastIndexOf(base, 0) !== 0;
  });

  return classlist.length ? classlist.join(" ").trim() : "";
}

/**
 * Converts a parallax into a settings object.
 *
 * @param {module:engine/view/element~Element|null} parallax
 *   The current parallax.
 * @return {{}}
 *   The settings.
 */
export function convertParallaxToSettings(parallax) {
  const settings = {};
  let row = false;

  settings.container_wrapper_class = extractParallaxClasses(parallax, "bs_parallax");

  // First child might be container or row.
  const firstChild = parallax.getChild(0);

  // Container.
  if (isBootstrapParallaxContainerWidget(firstChild)) {
    settings.add_container = 1;
    settings.container_class = extractParallaxClasses(firstChild, "container");

    // Container can have no classes, so need direct compare.
    const containerType = extractParallaxClasses(firstChild, "container", true);
    if (containerType.length) {
      if (containerType.indexOf("container-fluid") !== -1) {
        settings.container_type = "fluid";
      } else {
        settings.container_type = "default";
      }
    }
    row = firstChild.getChild(0);
  } else {
    row = firstChild;
  }

  // Row options.
  const rowClasses = extractParallaxClasses(row, "row");
  settings.no_gutter = rowClasses.indexOf("no-gutters") !== -1 ? 1 : 0;
  settings.row_class = rowClasses.replace("no-gutters", "").replace("g-0", "");

  // Layouts.
  settings.breakpoints = {
    none: { layout: row.getAttribute("data-row-none") },
    sm: { layout: row.getAttribute("data-row-sm") },
    md: { layout: row.getAttribute("data-row-md") },
    lg: { layout: row.getAttribute("data-row-lg") },
    xl: { layout: row.getAttribute("data-row-xl") },
    xxl: { layout: row.getAttribute("data-row-xxl") },
  };

  // Col options.
  settings.num_columns = 0;
  Array.from(row.getChildren()).forEach((col, idx) => {
    if (isBootstrapParallaxColWidget(col)) {
      settings.num_columns += 1;
      const colClass = extractParallaxClasses(col, "col");
      const key = `col_${idx + 1}_classes`;
      settings[key] = colClass;
    }
  });

  return settings;
}
